export interface Subject {
  id: string;
  name: string;
  icon: string;
  color: string;
  bgColor: string;
  description: string;
}

export const subjects: Subject[] = [
  {
    id: 'math',
    name: 'Mathematics',
    icon: '📐',
    color: 'text-blue-600',
    bgColor: 'bg-blue-50',
    description: 'Algebra, Calculus, Geometry & more',
  },
  {
    id: 'chemistry',
    name: 'Chemistry',
    icon: '⚗️',
    color: 'text-emerald-600',
    bgColor: 'bg-emerald-50',
    description: 'Equations, Reactions & Bonds',
  },
  {
    id: 'physics',
    name: 'Physics',
    icon: '⚡',
    color: 'text-orange-600',
    bgColor: 'bg-orange-50',
    description: 'Mechanics, Waves & Electricity',
  },
  {
    id: 'biology',
    name: 'Biology',
    icon: '🧬',
    color: 'text-green-600',
    bgColor: 'bg-green-50',
    description: 'Cells, Genetics & Ecology',
  },
  {
    id: 'statistics',
    name: 'Statistics',
    icon: '📊',
    color: 'text-purple-600',
    bgColor: 'bg-purple-50',
    description: 'Probability, Data & Analysis',
  },
  {
    id: 'calculus',
    name: 'Calculus',
    icon: '∫',
    color: 'text-rose-600',
    bgColor: 'bg-rose-50',
    description: 'Derivatives, Integrals & Limits',
  },
  {
    id: 'english',
    name: 'Writing',
    icon: '✍️',
    color: 'text-amber-600',
    bgColor: 'bg-amber-50',
    description: 'Essays, Grammar & Analysis',
  },
  {
    id: 'history',
    name: 'History',
    icon: '📜',
    color: 'text-red-600',
    bgColor: 'bg-red-50',
    description: 'Events, Dates & Context',
  },
];
