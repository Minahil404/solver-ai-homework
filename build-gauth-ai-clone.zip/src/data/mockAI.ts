export interface SolutionStep {
  step: number;
  title: string;
  content: string;
  formula?: string;
}

export interface AIResponse {
  subject: string;
  problem: string;
  answer: string;
  confidence: number;
  steps: SolutionStep[];
  relatedTopics: string[];
}

const mockSolutions: Record<string, AIResponse> = {
  math: {
    subject: 'Mathematics',
    problem: 'Solve for x: 3x² + 12x - 15 = 0',
    answer: 'x = 1 or x = -5',
    confidence: 98,
    steps: [
      { step: 1, title: 'Identify the quadratic equation', content: 'We have 3x² + 12x - 15 = 0, which is in standard form ax² + bx + c = 0', formula: 'a = 3, b = 12, c = -15' },
      { step: 2, title: 'Simplify by dividing by 3', content: 'Divide all terms by 3 to simplify', formula: 'x² + 4x - 5 = 0' },
      { step: 3, title: 'Factor the quadratic', content: 'Find two numbers that multiply to -5 and add to 4: (x + 5)(x - 1) = 0', formula: '(x + 5)(x - 1) = 0' },
      { step: 4, title: 'Apply zero product property', content: 'Set each factor equal to zero and solve', formula: 'x + 5 = 0 → x = -5\nx - 1 = 0 → x = 1' },
      { step: 5, title: 'Verify the solutions', content: 'Plug each value back into the original equation to confirm', formula: 'x = 1: 3(1)² + 12(1) - 15 = 3 + 12 - 15 = 0 ✓\nx = -5: 3(25) + 12(-5) - 15 = 75 - 60 - 15 = 0 ✓' },
    ],
    relatedTopics: ['Quadratic Formula', 'Factoring', 'Completing the Square', 'Discriminant'],
  },
  chemistry: {
    subject: 'Chemistry',
    problem: 'Balance the equation: Fe₂O₃ + CO → Fe + CO₂',
    answer: 'Fe₂O₃ + 3CO → 2Fe + 3CO₂',
    confidence: 97,
    steps: [
      { step: 1, title: 'Count atoms on each side', content: 'Left: Fe=2, O=4, C=1 | Right: Fe=1, O=2, C=1', formula: 'Unbalanced: Fe₂O₃ + CO → Fe + CO₂' },
      { step: 2, title: 'Balance iron (Fe)', content: 'Place coefficient 2 before Fe on the right', formula: 'Fe₂O₃ + CO → 2Fe + CO₂' },
      { step: 3, title: 'Balance oxygen (O)', content: 'Now O on left = 4, right = 2. Place coefficient 3 before CO₂', formula: 'Fe₂O₃ + CO → 2Fe + 3CO₂' },
      { step: 4, title: 'Balance carbon (C)', content: 'Right has 3 C, so place coefficient 3 before CO on left', formula: 'Fe₂O₃ + 3CO → 2Fe + 3CO₂' },
      { step: 5, title: 'Final verification', content: 'Left: Fe=2, O=6, C=3 | Right: Fe=2, O=6, C=3 ✓ Balanced!', formula: '' },
    ],
    relatedTopics: ['Stoichiometry', 'Redox Reactions', 'Oxidation Numbers', 'Mole Concept'],
  },
  physics: {
    subject: 'Physics',
    problem: 'A ball is thrown upward at 20 m/s. How high does it go?',
    answer: '20.4 meters',
    confidence: 96,
    steps: [
      { step: 1, title: 'Identify known values', content: 'Initial velocity, final velocity at peak, and acceleration due to gravity', formula: 'v₀ = 20 m/s\nv = 0 m/s (at peak)\ng = 9.8 m/s²' },
      { step: 2, title: 'Choose the right equation', content: 'Use v² = v₀² - 2gΔy (kinematic equation without time)', formula: 'v² = v₀² - 2gΔy' },
      { step: 3, title: 'Substitute and solve', content: 'Plug in values and solve for Δy', formula: '0 = (20)² - 2(9.8)Δy\n0 = 400 - 19.6Δy\n19.6Δy = 400\nΔy = 20.41 m' },
      { step: 4, title: 'Interpret the result', content: 'The ball reaches approximately 20.4 meters at its highest point', formula: '' },
    ],
    relatedTopics: ['Kinematics', 'Free Fall', 'Projectile Motion', 'Energy Conservation'],
  },
  biology: {
    subject: 'Biology',
    problem: 'Explain the process of DNA replication',
    answer: 'DNA replication is the semi-conservative process of copying DNA before cell division.',
    confidence: 94,
    steps: [
      { step: 1, title: 'Initiation', content: 'Helicase enzyme unwinds and unzips the double helix by breaking hydrogen bonds between base pairs', formula: '' },
      { step: 2, title: 'Primer Binding', content: 'Primase synthesizes short RNA primers on the template strands to provide starting points', formula: '' },
      { step: 3, title: 'Elongation — Leading Strand', content: 'DNA Polymerase III adds nucleotides continuously in the 5\'→3\' direction on the leading strand', formula: '' },
      { step: 4, title: 'Elongation — Lagging Strand', content: 'The lagging strand is synthesized discontinuously as Okazaki fragments in the 5\'→3\' direction', formula: '' },
      { step: 5, title: 'Termination & Proofreading', content: 'DNA Polymerase I replaces RNA primers with DNA. Ligase seals gaps. Proofreading ensures accuracy (~1 error per 10⁹ bases)', formula: '' },
    ],
    relatedTopics: ['Transcription', 'Translation', 'Cell Cycle', 'Mutations', 'DNA Repair'],
  },
  statistics: {
    subject: 'Statistics',
    problem: 'Find the mean, median, and mode of: 4, 8, 6, 5, 8, 3, 8',
    answer: 'Mean = 6, Median = 6, Mode = 8',
    confidence: 99,
    steps: [
      { step: 1, title: 'Sort the data', content: 'Arrange numbers in ascending order', formula: '3, 4, 5, 6, 8, 8, 8' },
      { step: 2, title: 'Calculate the mean', content: 'Sum all values and divide by count', formula: '(3+4+5+6+8+8+8) ÷ 7 = 42 ÷ 7 = 6' },
      { step: 3, title: 'Find the median', content: 'The middle value in the sorted list (n=7, so 4th value)', formula: 'Median = 6' },
      { step: 4, title: 'Find the mode', content: 'The most frequently occurring value', formula: '8 appears 3 times → Mode = 8' },
    ],
    relatedTopics: ['Standard Deviation', 'Variance', 'Frequency Distribution', 'Box Plots'],
  },
  calculus: {
    subject: 'Calculus',
    problem: 'Find the derivative: f(x) = x³ · sin(x)',
    answer: "f'(x) = 3x²·sin(x) + x³·cos(x)",
    confidence: 97,
    steps: [
      { step: 1, title: 'Recognize the structure', content: 'This is a product of two functions: u = x³ and v = sin(x)', formula: 'f(x) = u(x) · v(x)' },
      { step: 2, title: 'Apply the product rule', content: 'Product rule: (uv)\' = u\'v + uv\'', formula: "f'(x) = u'v + uv'" },
      { step: 3, title: 'Find u\' and v\'', content: 'Derivative of x³ is 3x². Derivative of sin(x) is cos(x)', formula: "u' = 3x²\nv' = cos(x)" },
      { step: 4, title: 'Substitute and simplify', content: 'Plug derivatives into product rule', formula: "f'(x) = 3x²·sin(x) + x³·cos(x)" },
    ],
    relatedTopics: ['Chain Rule', 'Quotient Rule', 'Implicit Differentiation', 'Integration by Parts'],
  },
  default: {
    subject: 'General',
    problem: 'Your scanned problem',
    answer: 'Scan a problem to get an AI-powered solution with step-by-step explanations.',
    confidence: 0,
    steps: [],
    relatedTopics: [],
  },
};

export function getMockSolution(subjectId: string): AIResponse {
  return mockSolutions[subjectId] || mockSolutions['default'];
}

export function getRandomSolution(): AIResponse {
  const keys = Object.keys(mockSolutions).filter((k) => k !== 'default');
  const randomKey = keys[Math.floor(Math.random() * keys.length)];
  return mockSolutions[randomKey];
}
