import { Link, useLocation } from 'react-router-dom';

export default function Header() {
  const location = useLocation();

  return (
    <header className="fixed top-0 left-0 right-0 z-50 glass border-b border-white/50">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6">
        <Link to="/" className="flex items-center gap-2.5 group">
          <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-violet-500 to-indigo-600 shadow-md shadow-indigo-200 group-hover:shadow-lg group-hover:scale-105 transition-all duration-200">
            <svg className="h-5 w-5 text-white" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2.5} strokeLinecap="round" strokeLinejoin="round">
              <path d="M12 2L2 7l10 5 10-5-10-5z" />
              <path d="M2 17l10 5 10-5" />
              <path d="M2 12l10 5 10-5" />
            </svg>
          </div>
          <span className="text-xl font-bold tracking-tight">
            <span className="text-violet-600">Solver</span>
            <span className="text-gray-900">AI</span>
          </span>
        </Link>

        <nav className="hidden sm:flex items-center gap-1">
          {[
            { to: '/', label: 'Home' },
            { to: '/scan', label: 'Scan' },
            { to: '/history', label: 'History' },
          ].map((link) => (
            <Link
              key={link.to}
              to={link.to}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-all duration-200 ${
                location.pathname === link.to
                  ? 'bg-violet-100 text-violet-700'
                  : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
              }`}
            >
              {link.label}
            </Link>
          ))}
        </nav>

        <div className="flex items-center gap-3">
          <button className="hidden sm:flex items-center gap-2 px-4 py-2 rounded-xl bg-gradient-to-r from-violet-500 to-indigo-600 text-white text-sm font-semibold shadow-md shadow-indigo-200 hover:shadow-lg hover:scale-105 transition-all duration-200">
            <svg className="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2.5}>
              <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" />
              <circle cx="12" cy="7" r="4" />
            </svg>
            Sign In
          </button>
          {/* Mobile nav */}
          <div className="flex sm:hidden items-center gap-2">
            {[
              { to: '/', icon: '🏠' },
              { to: '/scan', icon: '📷' },
              { to: '/history', icon: '📋' },
            ].map((link) => (
              <Link
                key={link.to}
                to={link.to}
                className={`w-9 h-9 flex items-center justify-center rounded-lg text-lg transition-all ${
                  location.pathname === link.to ? 'bg-violet-100 scale-110' : 'hover:bg-gray-100'
                }`}
              >
                {link.icon}
              </Link>
            ))}
          </div>
        </div>
      </div>
    </header>
  );
}
