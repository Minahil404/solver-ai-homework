import { useState, useRef, useEffect, useCallback } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { subjects } from '../data/subjects';

export default function Scanner() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const [mode, setMode] = useState<'camera' | 'upload'>('camera');
  const [capturedImage, setCapturedImage] = useState<string | null>(null);
  const [selectedSubject, setSelectedSubject] = useState(searchParams.get('subject') || 'auto');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [cameraError, setCameraError] = useState('');
  const [dragOver, setDragOver] = useState(false);

  // Start camera
  const startCamera = useCallback(async () => {
    setCameraError('');
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment', width: { ideal: 1920 }, height: { ideal: 1080 } },
      });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
    } catch {
      setCameraError('Camera access denied. Please use upload mode instead.');
      setMode('upload');
    }
  }, []);

  // Stop camera
  const stopCamera = useCallback(() => {
    if (videoRef.current && videoRef.current.srcObject) {
      const stream = videoRef.current.srcObject as MediaStream;
      stream.getTracks().forEach((track) => track.stop());
      videoRef.current.srcObject = null;
    }
  }, []);

  useEffect(() => {
    if (mode === 'camera') {
      startCamera();
    } else {
      stopCamera();
    }
    return () => stopCamera();
  }, [mode, startCamera, stopCamera]);

  // Capture photo
  const capturePhoto = () => {
    if (!videoRef.current || !canvasRef.current) return;
    const video = videoRef.current;
    const canvas = canvasRef.current;
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.drawImage(video, 0, 0);
      setCapturedImage(canvas.toDataURL('image/jpeg', 0.9));
      stopCamera();
    }
  };

  // Handle file upload
  const handleFile = (file: File) => {
    if (!file.type.startsWith('image/')) return;
    const reader = new FileReader();
    reader.onload = (e) => {
      setCapturedImage(e.target?.result as string);
      setMode('upload');
    };
    reader.readAsDataURL(file);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    const file = e.dataTransfer.files[0];
    if (file) handleFile(file);
  };

  // Simulate AI analysis and navigate to results
  const analyzeProblem = async () => {
    setIsAnalyzing(true);
    // Simulate processing delay
    await new Promise((r) => setTimeout(r, 1800 + Math.random() * 1500));
    setIsAnalyzing(false);

    const subject = selectedSubject === 'auto'
      ? subjects[Math.floor(Math.random() * (subjects.length - 1))].id
      : selectedSubject;

    navigate(`/results?subject=${subject}`, {
      state: { image: capturedImage, subject },
    });
  };

  const resetCapture = () => {
    setCapturedImage(null);
    if (mode === 'camera') startCamera();
  };

  return (
    <div className="min-h-screen pt-20 pb-12 px-4 sm:px-6">
      <div className="mx-auto max-w-2xl">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-2xl sm:text-3xl font-bold text-gray-900">
            {capturedImage ? 'Review & Solve' : 'Scan Your Problem'}
          </h1>
          <p className="text-gray-500 mt-2">
            {capturedImage
              ? 'Select a subject and let AI work its magic'
              : 'Take a photo or upload an image of your homework problem'}
          </p>
        </div>

        {/* Mode Toggle (only when no image captured) */}
        {!capturedImage && (
          <div className="flex justify-center mb-6">
            <div className="flex bg-gray-100 rounded-xl p-1 gap-1">
              <button
                onClick={() => setMode('camera')}
                className={`px-5 py-2.5 rounded-lg text-sm font-medium transition-all ${
                  mode === 'camera'
                    ? 'bg-white text-gray-900 shadow-sm'
                    : 'text-gray-500 hover:text-gray-700'
                }`}
              >
                📷 Camera
              </button>
              <button
                onClick={() => setMode('upload')}
                className={`px-5 py-2.5 rounded-lg text-sm font-medium transition-all ${
                  mode === 'upload'
                    ? 'bg-white text-gray-900 shadow-sm'
                    : 'text-gray-500 hover:text-gray-700'
                }`}
              >
                📁 Upload
              </button>
            </div>
          </div>
        )}

        {/* Camera / Upload Area */}
        {!capturedImage ? (
          <div
            onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
            onDragLeave={() => setDragOver(false)}
            onDrop={handleDrop}
            className={`relative rounded-2xl overflow-hidden border-2 transition-all ${
              dragOver
                ? 'border-violet-500 bg-violet-50 scale-[1.02]'
                : 'border-gray-200 bg-gray-900'
            }`}
          >
            {mode === 'camera' ? (
              <div className="relative aspect-[4/3] bg-black">
                {cameraError ? (
                  <div className="absolute inset-0 flex flex-col items-center justify-center text-white p-6">
                    <span className="text-4xl mb-3">📷</span>
                    <p className="text-center text-white/70 mb-4">{cameraError}</p>
                    <button
                      onClick={() => setMode('upload')}
                      className="px-6 py-2.5 rounded-xl bg-violet-600 text-white font-medium hover:bg-violet-700 transition-colors"
                    >
                      Switch to Upload
                    </button>
                  </div>
                ) : (
                  <>
                    <video
                      ref={videoRef}
                      autoPlay
                      playsInline
                      muted
                      className="w-full h-full object-cover"
                    />
                    {/* Scan overlay */}
                    <div className="absolute inset-0 pointer-events-none">
                      {/* Corner brackets */}
                      <div className="absolute top-8 left-8 w-12 h-12 border-t-4 border-l-4 border-violet-400 rounded-tl-xl" />
                      <div className="absolute top-8 right-8 w-12 h-12 border-t-4 border-r-4 border-violet-400 rounded-tr-xl" />
                      <div className="absolute bottom-8 left-8 w-12 h-12 border-b-4 border-l-4 border-violet-400 rounded-bl-xl" />
                      <div className="absolute bottom-8 right-8 w-12 h-12 border-b-4 border-r-4 border-violet-400 rounded-br-xl" />
                      {/* Scanning line */}
                      <div className="absolute left-8 right-8 h-0.5 bg-gradient-to-r from-transparent via-violet-400 to-transparent animate-pulse"
                        style={{ top: '50%' }}
                      />
                    </div>
                    {/* Capture button */}
                    <button
                      onClick={capturePhoto}
                      className="absolute bottom-6 left-1/2 -translate-x-1/2 flex items-center justify-center w-16 h-16 rounded-full bg-white/90 backdrop-blur shadow-lg hover:scale-110 transition-transform border-4 border-violet-500"
                    >
                      <div className="w-12 h-12 rounded-full bg-white" />
                    </button>
                  </>
                )}
              </div>
            ) : (
              <div
                onClick={() => fileInputRef.current?.click()}
                className="aspect-[4/3] flex flex-col items-center justify-center cursor-pointer bg-gradient-to-br from-gray-50 to-gray-100 hover:from-violet-50 hover:to-indigo-50 transition-colors"
              >
                <div className="w-20 h-20 rounded-2xl bg-violet-100 flex items-center justify-center mb-4">
                  <svg className="h-10 w-10 text-violet-500" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.5}>
                    <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
                    <polyline points="17,8 12,3 7,8" />
                    <line x1="12" y1="3" x2="12" y2="15" />
                  </svg>
                </div>
                <p className="text-gray-600 font-medium">Click to upload or drag & drop</p>
                <p className="text-gray-400 text-sm mt-1">PNG, JPG, HEIC up to 10MB</p>
              </div>
            )}
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              className="hidden"
              onChange={(e) => e.target.files?.[0] && handleFile(e.target.files[0])}
            />
          </div>
        ) : (
          /* Captured Image Preview */
          <div className="rounded-2xl overflow-hidden border-2 border-violet-200 shadow-lg">
            <img
              src={capturedImage}
              alt="Captured problem"
              className="w-full aspect-[4/3] object-cover"
            />
          </div>
        )}

        {/* Subject Selector */}
        {capturedImage && (
          <div className="mt-6 space-y-4 animate-slide-up">
            <label className="block text-sm font-semibold text-gray-700">
              Select Subject (or Auto-Detect)
            </label>
            <div className="grid grid-cols-3 sm:grid-cols-5 gap-2">
              <button
                onClick={() => setSelectedSubject('auto')}
                className={`p-3 rounded-xl text-sm font-medium transition-all ${
                  selectedSubject === 'auto'
                    ? 'bg-gradient-to-r from-violet-500 to-indigo-600 text-white shadow-md shadow-indigo-200'
                    : 'bg-white border border-gray-200 text-gray-600 hover:border-violet-300'
                }`}
              >
                🤖 Auto
              </button>
              {subjects.slice(0, 8).map((s) => (
                <button
                  key={s.id}
                  onClick={() => setSelectedSubject(s.id)}
                  className={`p-3 rounded-xl text-sm font-medium transition-all ${
                    selectedSubject === s.id
                      ? 'bg-gradient-to-r from-violet-500 to-indigo-600 text-white shadow-md shadow-indigo-200'
                      : 'bg-white border border-gray-200 text-gray-600 hover:border-violet-300'
                  }`}
                >
                  {s.icon} {s.name}
                </button>
              ))}
            </div>

            {/* Action Buttons */}
            <div className="flex gap-3 pt-4">
              <button
                onClick={resetCapture}
                className="flex-1 px-4 py-3 rounded-xl border-2 border-gray-200 text-gray-600 font-medium hover:bg-gray-50 transition-colors"
              >
                Retake
              </button>
              <button
                onClick={analyzeProblem}
                disabled={isAnalyzing}
                className="flex-[2] flex items-center justify-center gap-2 px-6 py-3 rounded-xl gradient-brand text-white font-semibold shadow-lg shadow-indigo-200 hover:shadow-xl hover:scale-[1.02] transition-all disabled:opacity-70 disabled:cursor-wait"
              >
                {isAnalyzing ? (
                  <>
                    <svg className="animate-spin h-5 w-5" viewBox="0 0 24 24" fill="none">
                      <circle cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="3" opacity="0.25" />
                      <path d="M12 2a10 10 0 0 1 10 10" stroke="currentColor" strokeWidth="3" strokeLinecap="round" />
                    </svg>
                    Analyzing...
                  </>
                ) : (
                  <>
                    <svg className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2.5}>
                      <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
                    </svg>
                    Solve Problem
                  </>
                )}
              </button>
            </div>
          </div>
        )}

        {/* Quick upload button when camera is active */}
        {!capturedImage && mode === 'camera' && !cameraError && (
          <div className="mt-4 text-center">
            <button
              onClick={() => setMode('upload')}
              className="text-sm text-violet-600 hover:text-violet-700 font-medium"
            >
              📁 Or upload from gallery
            </button>
          </div>
        )}

        <canvas ref={canvasRef} className="hidden" />
      </div>
    </div>
  );
}
