import { useState, useEffect } from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import { getMockSolution, type AIResponse } from '../data/mockAI';

export default function Results() {
  const [searchParams] = useSearchParams();
  const subjectId = searchParams.get('subject') || 'math';
  const [solution, setSolution] = useState<AIResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [expandedStep, setExpandedStep] = useState<number | null>(null);
  const [satisfaction, setSatisfaction] = useState<'up' | 'down' | null>(null);

  useEffect(() => {
    setLoading(true);
    // Simulate AI processing time
    const timer = setTimeout(() => {
      setSolution(getMockSolution(subjectId));
      setLoading(false);
    }, 2000);
    return () => clearTimeout(timer);
  }, [subjectId]);

  if (loading) {
    return (
      <div className="min-h-screen pt-20 px-4 sm:px-6">
        <div className="mx-auto max-w-3xl">
          {/* Loading skeleton */}
          <div className="animate-slide-up">
            <div className="shimmer h-8 w-48 rounded-lg mb-4" />
            <div className="shimmer h-4 w-72 rounded mb-8" />
            <div className="shimmer h-48 rounded-2xl mb-6" />
            <div className="space-y-4">
              {[1, 2, 3, 4].map((i) => (
                <div key={i} className="shimmer h-20 rounded-xl" />
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (!solution) return null;

  return (
    <div className="min-h-screen pt-20 pb-16 px-4 sm:px-6">
      <div className="mx-auto max-w-3xl">
        {/* Breadcrumb & Confidence */}
        <div className="flex items-center justify-between mb-6 animate-slide-up">
          <div className="flex items-center gap-2 text-sm text-gray-500">
            <Link to="/" className="hover:text-violet-600 transition-colors">Home</Link>
            <span>/</span>
            <Link to="/scan" className="hover:text-violet-600 transition-colors">Scan</Link>
            <span>/</span>
            <span className="text-gray-900 font-medium">Solution</span>
          </div>
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-emerald-50 text-emerald-700 text-sm font-semibold">
            <span className="relative flex h-2 w-2">
              <span className="absolute inline-flex h-full w-full rounded-full bg-emerald-400"></span>
            </span>
            {solution.confidence}% Confidence
          </div>
        </div>

        {/* Problem Header */}
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6 sm:p-8 mb-6 animate-slide-up" style={{ animationDelay: '0.05s' }}>
          <div className="flex items-start gap-4">
            <div className="flex-shrink-0 w-12 h-12 rounded-xl bg-violet-100 flex items-center justify-center text-2xl">
              {solution.subject === 'Mathematics' ? '📐' :
               solution.subject === 'Chemistry' ? '⚗️' :
               solution.subject === 'Physics' ? '⚡' :
               solution.subject === 'Biology' ? '🧬' :
               solution.subject === 'Statistics' ? '📊' :
               solution.subject === 'Calculus' ? '∫' : '📝'}
            </div>
            <div>
              <div className="text-xs font-semibold text-violet-500 uppercase tracking-wide mb-1">{solution.subject}</div>
              <h2 className="text-lg font-semibold text-gray-900 mb-1">{solution.problem}</h2>
            </div>
          </div>
        </div>

        {/* Answer Card */}
        <div className="relative rounded-2xl overflow-hidden mb-6 animate-slide-up" style={{ animationDelay: '0.1s' }}>
          <div className="absolute inset-0 gradient-brand opacity-95" />
          <div className="relative p-6 sm:p-8 text-white">
            <div className="text-sm font-medium text-white/70 mb-2">ANSWER</div>
            <div className="text-2xl sm:text-3xl font-extrabold leading-relaxed whitespace-pre-wrap">
              {solution.answer}
            </div>
            <div className="mt-4 flex items-center gap-3">
              <button
                onClick={() => navigator.clipboard.writeText(solution.answer)}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white/20 hover:bg-white/30 text-white text-sm font-medium transition-colors"
              >
                <svg className="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2}>
                  <rect x="9" y="9" width="13" height="13" rx="2" />
                  <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1" />
                </svg>
                Copy
              </button>
            </div>
          </div>
        </div>

        {/* Steps */}
        <div className="mb-6 animate-slide-up" style={{ animationDelay: '0.15s' }}>
          <h3 className="text-lg font-bold text-gray-900 mb-4">Step-by-Step Solution</h3>
          <div className="space-y-3">
            {solution.steps.map((step, idx) => (
              <div
                key={step.step}
                className="bg-white rounded-xl border border-gray-100 shadow-sm overflow-hidden transition-all"
              >
                <button
                  onClick={() => setExpandedStep(expandedStep === idx ? null : idx)}
                  className="w-full flex items-center gap-4 p-4 text-left hover:bg-gray-50 transition-colors"
                >
                  <div className={`flex-shrink-0 w-9 h-9 rounded-lg flex items-center justify-center text-sm font-bold transition-colors ${
                    expandedStep === idx
                      ? 'bg-violet-600 text-white'
                      : 'bg-violet-100 text-violet-700'
                  }`}>
                    {step.step}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="font-semibold text-gray-900">{step.title}</div>
                    <div className="text-sm text-gray-500 truncate">{step.content}</div>
                  </div>
                  <svg
                    className={`w-5 h-5 text-gray-400 transition-transform ${expandedStep === idx ? 'rotate-180' : ''}`}
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth={2}
                  >
                    <path d="M6 9l6 6 6-6" />
                  </svg>
                </button>
                {expandedStep === idx && (
                  <div className="px-4 pb-4 pt-0 pl-16 animate-slide-up">
                    <p className="text-gray-600 text-sm leading-relaxed">{step.content}</p>
                    {step.formula && (
                      <div className="mt-3 p-3 rounded-lg bg-gray-50 border border-gray-100 font-mono text-sm text-gray-800 whitespace-pre-wrap">
                        {step.formula}
                      </div>
                    )}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Related Topics */}
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6 mb-6 animate-slide-up" style={{ animationDelay: '0.2s' }}>
          <h3 className="text-sm font-semibold text-gray-900 mb-3">Related Topics</h3>
          <div className="flex flex-wrap gap-2">
            {solution.relatedTopics.map((topic) => (
              <span
                key={topic}
                className="px-3 py-1.5 rounded-lg bg-violet-50 text-violet-700 text-sm font-medium hover:bg-violet-100 cursor-pointer transition-colors"
              >
                {topic}
              </span>
            ))}
          </div>
        </div>

        {/* Feedback */}
        <div className="text-center animate-slide-up" style={{ animationDelay: '0.25s' }}>
          <p className="text-sm text-gray-500 mb-3">Was this solution helpful?</p>
          <div className="flex items-center justify-center gap-3">
            <button
              onClick={() => setSatisfaction('up')}
              className={`p-3 rounded-xl border-2 transition-all ${
                satisfaction === 'up'
                  ? 'border-emerald-400 bg-emerald-50 text-emerald-600 shadow-sm'
                  : 'border-gray-200 text-gray-400 hover:border-gray-300'
              }`}
            >
              <svg className="h-6 w-6" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2}>
                <path d="M14 9V5a3 3 0 0 0-3-3l-4 9v11h11.28a2 2 0 0 0 2-1.7l1.38-9a2 2 0 0 0-2-2.3H14z" />
              </svg>
            </button>
            <button
              onClick={() => setSatisfaction('down')}
              className={`p-3 rounded-xl border-2 transition-all ${
                satisfaction === 'down'
                  ? 'border-red-400 bg-red-50 text-red-500 shadow-sm'
                  : 'border-gray-200 text-gray-400 hover:border-gray-300'
              }`}
            >
              <svg className="h-6 w-6" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2}>
                <path d="M10 15v4a3 3 0 0 0 3 3l4-9V2H5.72a2 2 0 0 0-2 1.7l-1.38 9a2 2 0 0 0 2 2.3H10z" />
              </svg>
            </button>
          </div>
          {satisfaction && (
            <p className="text-sm text-gray-500 mt-2 animate-slide-up">
              {satisfaction === 'up' ? '🎉 Thanks for your feedback!' : 'Thanks — we\'ll work on improving!'}
            </p>
          )}
        </div>

        {/* CTA */}
        <div className="mt-8 text-center animate-slide-up" style={{ animationDelay: '0.3s' }}>
          <Link
            to="/scan"
            className="inline-flex items-center gap-2 px-8 py-4 rounded-xl gradient-brand text-white font-semibold shadow-lg shadow-indigo-200 hover:shadow-xl hover:scale-105 transition-all duration-200"
          >
            <svg className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2}>
              <path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z" />
              <circle cx="12" cy="13" r="4" />
            </svg>
            Scan Another Problem
          </Link>
        </div>
      </div>
    </div>
  );
}
