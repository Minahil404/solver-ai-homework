import { useState } from 'react';
import { Link } from 'react-router-dom';
import { subjects } from '../data/subjects';

interface HistoryItem {
  id: string;
  date: string;
  subject: string;
  subjectIcon: string;
  problem: string;
  answer: string;
}

const mockHistory: HistoryItem[] = [
  { id: '1', date: '2 minutes ago', subject: 'Mathematics', subjectIcon: '📐', problem: 'Solve for x: 3x² + 12x - 15 = 0', answer: 'x = 1 or x = -5' },
  { id: '2', date: '1 hour ago', subject: 'Chemistry', subjectIcon: '⚗️', problem: 'Balance: Fe₂O₃ + CO → Fe + CO₂', answer: 'Fe₂O₃ + 3CO → 2Fe + 3CO₂' },
  { id: '3', date: '3 hours ago', subject: 'Physics', subjectIcon: '⚡', problem: 'Ball thrown upward at 20 m/s. Max height?', answer: '20.4 meters' },
  { id: '4', date: 'Yesterday', subject: 'Biology', subjectIcon: '🧬', problem: 'Explain DNA replication process', answer: 'Semi-conservative replication with leading/lagging strands' },
  { id: '5', date: 'Yesterday', subject: 'Statistics', subjectIcon: '📊', problem: 'Mean, median, mode of: 4, 8, 6, 5, 8, 3, 8', answer: 'Mean = 6, Median = 6, Mode = 8' },
  { id: '6', date: '2 days ago', subject: 'Calculus', subjectIcon: '∫', problem: "Find f'(x) for f(x) = x³ · sin(x)", answer: "f'(x) = 3x²·sin(x) + x³·cos(x)" },
];

export default function History() {
  const [filter, setFilter] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');

  const filtered = mockHistory.filter((item) => {
    if (filter !== 'all' && item.subject !== filter) return false;
    if (searchTerm && !item.problem.toLowerCase().includes(searchTerm.toLowerCase())) return false;
    return true;
  });

  const uniqueSubjects = [...new Set(mockHistory.map((h) => h.subject))];

  return (
    <div className="min-h-screen pt-20 pb-16 px-4 sm:px-6">
      <div className="mx-auto max-w-3xl">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-2xl sm:text-3xl font-bold text-gray-900">Problem History</h1>
          <p className="text-gray-500 mt-1">Review your previously solved problems</p>
        </div>

        {/* Search & Filter */}
        <div className="flex flex-col sm:flex-row gap-3 mb-6">
          <div className="relative flex-1">
            <svg className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2}>
              <circle cx="11" cy="11" r="8" />
              <path d="M21 21l-4.35-4.35" />
            </svg>
            <input
              type="text"
              placeholder="Search problems..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-gray-200 bg-white text-sm focus:outline-none focus:border-violet-400 focus:ring-2 focus:ring-violet-100 transition-all"
            />
          </div>
          <select
            value={filter}
            onChange={(e) => setFilter(e.target.value)}
            className="px-4 py-2.5 rounded-xl border border-gray-200 bg-white text-sm text-gray-700 focus:outline-none focus:border-violet-400 focus:ring-2 focus:ring-violet-100 transition-all"
          >
            <option value="all">All Subjects</option>
            {uniqueSubjects.map((s) => (
              <option key={s} value={s}>{s}</option>
            ))}
          </select>
        </div>

        {/* History List */}
        {filtered.length === 0 ? (
          <div className="text-center py-16">
            <div className="text-5xl mb-4">📋</div>
            <h3 className="text-lg font-semibold text-gray-900 mb-2">No problems found</h3>
            <p className="text-gray-500 mb-6">
              {searchTerm ? 'Try a different search term' : 'Start scanning problems to build your history'}
            </p>
            <Link
              to="/scan"
              className="inline-flex items-center gap-2 px-6 py-3 rounded-xl gradient-brand text-white font-semibold shadow-lg shadow-indigo-200 hover:shadow-xl transition-all"
            >
              <svg className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2}>
                <path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z" />
                <circle cx="12" cy="13" r="4" />
              </svg>
              Scan a Problem
            </Link>
          </div>
        ) : (
          <div className="space-y-3">
            {filtered.map((item) => (
              <Link
                key={item.id}
                to={`/results?subject=${subjects.find(s => s.name === item.subject)?.id || 'math'}`}
                className="block bg-white rounded-xl border border-gray-100 shadow-sm p-4 hover:shadow-md hover:border-violet-200 transition-all group"
              >
                <div className="flex items-start gap-3">
                  <div className="flex-shrink-0 w-10 h-10 rounded-lg bg-violet-100 flex items-center justify-center text-lg group-hover:scale-110 transition-transform">
                    {item.subjectIcon}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-0.5">
                      <span className="text-xs font-semibold text-violet-500">{item.subject}</span>
                      <span className="text-xs text-gray-400">·</span>
                      <span className="text-xs text-gray-400">{item.date}</span>
                    </div>
                    <p className="text-sm font-medium text-gray-900 truncate">{item.problem}</p>
                    <p className="text-xs text-gray-500 mt-1 truncate">
                      <span className="text-emerald-600 font-medium">Answer:</span> {item.answer}
                    </p>
                  </div>
                  <div className="flex-shrink-0 text-gray-300 group-hover:text-violet-400 transition-colors">
                    <svg className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2}>
                      <path d="M9 18l6-6-6-6" />
                    </svg>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        )}

        {/* Stats Summary */}
        <div className="mt-8 p-6 rounded-2xl bg-white border border-gray-100 shadow-sm">
          <h3 className="font-semibold text-gray-900 mb-4">Your Stats</h3>
          <div className="grid grid-cols-3 gap-4 text-center">
            <div>
              <div className="text-2xl font-bold text-violet-600">{mockHistory.length}</div>
              <div className="text-xs text-gray-500">Problems Solved</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-violet-600">{uniqueSubjects.length}</div>
              <div className="text-xs text-gray-500">Subjects Covered</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-violet-600">98%</div>
              <div className="text-xs text-gray-500">Satisfaction</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
