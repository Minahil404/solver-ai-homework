import { Link } from 'react-router-dom';
import { subjects } from '../data/subjects';
import { useState, useEffect } from 'react';

const stats = [
  { value: '350M+', label: 'Problems Solved' },
  { value: '50M+', label: 'Students Helped' },
  { value: '98%', label: 'Accuracy Rate' },
  { value: '24/7', label: 'AI Availability' },
];

const testimonials = [
  { name: 'Sarah K.', role: 'High School Senior', text: 'This app literally saved my calculus grade. The step-by-step explanations are incredible!' },
  { name: 'Marcus T.', role: 'College Freshman', text: 'I use it for chemistry problems every day. It\'s like having a tutor in my pocket.' },
  { name: 'Emily R.', role: 'Parent', text: 'My daughter went from struggling in math to acing her exams. Thank you SolverAI!' },
];

const floatingShapes = [
  '🔢', '📐', '⚗️', '🧪', '🔬', '🧮', '📏', '💡', '🎯', '⭐',
];

export default function Home() {
  const [shapes, setShapes] = useState<{ emoji: string; x: number; y: number; delay: number; duration: number }[]>([]);

  useEffect(() => {
    setShapes(
      Array.from({ length: 12 }, (_, i) => ({
        emoji: floatingShapes[i % floatingShapes.length],
        x: Math.random() * 100,
        y: Math.random() * 100,
        delay: Math.random() * 5,
        duration: 15 + Math.random() * 20,
      }))
    );
  }, []);

  return (
    <div className="min-h-screen">
      {/* Floating background shapes */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden -z-10">
        {shapes.map((s, i) => (
          <span
            key={i}
            className="absolute text-2xl opacity-10"
            style={{
              left: `${s.x}%`,
              top: `${s.y}%`,
              animation: `float ${s.duration}s ${s.delay}s infinite ease-in-out`,
            }}
          >
            {s.emoji}
          </span>
        ))}
      </div>

      {/* Hero Section */}
      <section className="relative pt-32 pb-20 px-4 sm:px-6">
        <div className="mx-auto max-w-4xl text-center">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-violet-100 text-violet-700 text-sm font-medium mb-8 animate-slide-up">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-violet-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-violet-500"></span>
            </span>
            AI-Powered Homework Helper
          </div>

          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-gray-900 mb-6 animate-slide-up">
            Point your camera at{' '}
            <span className="gradient-brand-text">any problem</span>
          </h1>

          <p className="text-lg sm:text-xl text-gray-500 max-w-2xl mx-auto mb-10 animate-slide-up" style={{ animationDelay: '0.1s' }}>
            Get instant, step-by-step solutions for math, chemistry, physics, biology, and more. Powered by advanced AI that understands handwritten and printed problems.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 animate-slide-up" style={{ animationDelay: '0.2s' }}>
            <Link
              to="/scan"
              className="group flex items-center gap-3 px-8 py-4 rounded-2xl gradient-brand text-white text-lg font-semibold shadow-xl shadow-indigo-300/50 hover:shadow-2xl hover:shadow-indigo-300/60 hover:scale-105 transition-all duration-300"
            >
              <svg className="h-6 w-6 group-hover:scale-110 transition-transform" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2}>
                <path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z" />
                <circle cx="12" cy="13" r="4" />
              </svg>
              Start Scanning Now
            </Link>
            <Link
              to="/scan"
              className="flex items-center gap-2 px-6 py-4 rounded-2xl bg-white border-2 border-gray-200 text-gray-700 font-semibold hover:border-violet-300 hover:text-violet-600 transition-all duration-200"
            >
              <svg className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2}>
                <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
                <polyline points="17,8 12,3 7,8" />
                <line x1="12" y1="3" x2="12" y2="15" />
              </svg>
              Upload Image
            </Link>
          </div>

          {/* Scan Preview */}
          <div className="mt-16 mx-auto max-w-md animate-slide-up" style={{ animationDelay: '0.3s' }}>
            <div className="relative rounded-2xl overflow-hidden shadow-2xl shadow-gray-300/50 border-4 border-white">
              <div className="aspect-[4/3] bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 flex items-center justify-center relative">
                <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(124,58,237,0.15),transparent_70%)]" />
                <div className="relative text-center">
                  <div className="text-5xl mb-3">📝</div>
                  <div className="text-white/60 text-sm font-mono">
                    3x² + 12x - 15 = 0
                  </div>
                  <div className="mt-3 flex items-center justify-center gap-1">
                    <span className="w-2 h-2 bg-violet-400 rounded-full scan-ring" />
                    <span className="text-violet-300 text-xs">AI Ready</span>
                  </div>
                </div>
                {/* Scan lines */}
                <div className="absolute inset-0 bg-gradient-to-b from-transparent via-violet-500/5 to-transparent animate-pulse" />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="py-16 px-4 sm:px-6">
        <div className="mx-auto max-w-5xl">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {stats.map((stat) => (
              <div key={stat.label} className="text-center p-6 rounded-2xl bg-white border border-gray-100 shadow-sm hover:shadow-md transition-shadow">
                <div className="text-2xl sm:text-3xl font-extrabold gradient-brand-text">{stat.value}</div>
                <div className="text-sm text-gray-500 mt-1">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Subjects Grid */}
      <section className="py-12 px-4 sm:px-6">
        <div className="mx-auto max-w-5xl">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-3">All Subjects Covered</h2>
            <p className="text-gray-500">From algebra to zoology — we've got you covered</p>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
            {subjects.map((subject) => (
              <Link
                key={subject.id}
                to={`/scan?subject=${subject.id}`}
                className={`group p-5 rounded-2xl ${subject.bgColor} border border-transparent hover:border-violet-200 hover:shadow-lg hover:shadow-violet-100 transition-all duration-200`}
              >
                <div className="text-3xl mb-3 group-hover:scale-110 transition-transform duration-200 inline-block">
                  {subject.icon}
                </div>
                <h3 className={`font-semibold text-gray-900 mb-1`}>{subject.name}</h3>
                <p className="text-xs text-gray-500">{subject.description}</p>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-16 px-4 sm:px-6 bg-white">
        <div className="mx-auto max-w-5xl">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-3">How It Works</h2>
            <p className="text-gray-500">Three simple steps to solve any problem</p>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            {[
              { step: '01', icon: '📸', title: 'Snap or Upload', desc: 'Take a photo of your problem or upload from your gallery. Our AI reads both handwritten and printed text.' },
              { step: '02', icon: '🧠', title: 'AI Analyzes', desc: 'Our advanced AI model processes your problem, identifies the subject, and computes the solution in seconds.' },
              { step: '03', icon: '💡', title: 'Learn & Understand', desc: 'Get detailed step-by-step explanations, not just answers. Learn the concepts behind every solution.' },
            ].map((item) => (
              <div key={item.step} className="text-center p-6">
                <div className="text-4xl mb-4">{item.icon}</div>
                <div className="text-xs font-bold text-violet-500 mb-2">STEP {item.step}</div>
                <h3 className="font-semibold text-gray-900 mb-2">{item.title}</h3>
                <p className="text-sm text-gray-500">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-16 px-4 sm:px-6">
        <div className="mx-auto max-w-5xl">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-3">What Students Say</h2>
          </div>
          <div className="grid md:grid-cols-3 gap-6">
            {testimonials.map((t) => (
              <div key={t.name} className="p-6 rounded-2xl bg-white border border-gray-100 shadow-sm hover:shadow-md transition-shadow">
                <div className="flex gap-1 mb-3 text-amber-400">
                  {'★'.repeat(5)}
                </div>
                <p className="text-gray-600 text-sm mb-4 leading-relaxed">"{t.text}"</p>
                <div>
                  <div className="font-semibold text-gray-900 text-sm">{t.name}</div>
                  <div className="text-xs text-gray-400">{t.role}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 px-4 sm:px-6">
        <div className="mx-auto max-w-3xl text-center">
          <div className="p-10 sm:p-16 rounded-3xl gradient-brand shadow-2xl shadow-indigo-300/40">
            <h2 className="text-3xl sm:text-4xl font-extrabold text-white mb-4">
              Ready to Ace Your Homework?
            </h2>
            <p className="text-white/80 mb-8 text-lg">
              Join millions of students who are learning smarter with SolverAI.
            </p>
            <Link
              to="/scan"
              className="inline-flex items-center gap-2 px-8 py-4 rounded-2xl bg-white text-violet-700 font-bold text-lg shadow-lg hover:shadow-xl hover:scale-105 transition-all duration-200"
            >
              Get Started Free
              <svg className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2.5}>
                <path d="M5 12h14M12 5l7 7-7 7" />
              </svg>
            </Link>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 px-4 sm:px-6 border-t border-gray-100">
        <div className="mx-auto max-w-5xl flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2 text-gray-400 text-sm">
            <span className="font-bold text-gray-500">SolverAI</span>
            <span>© 2026</span>
          </div>
          <div className="flex gap-6 text-sm text-gray-400">
            <a href="#" className="hover:text-gray-600 transition-colors">Privacy</a>
            <a href="#" className="hover:text-gray-600 transition-colors">Terms</a>
            <a href="#" className="hover:text-gray-600 transition-colors">Contact</a>
          </div>
        </div>
      </footer>

      <style>{`
        @keyframes float {
          0%, 100% { transform: translateY(0px) rotate(0deg); }
          25% { transform: translateY(-30px) rotate(5deg); }
          50% { transform: translateY(-15px) rotate(-3deg); }
          75% { transform: translateY(-40px) rotate(2deg); }
        }
      `}</style>
    </div>
  );
}
